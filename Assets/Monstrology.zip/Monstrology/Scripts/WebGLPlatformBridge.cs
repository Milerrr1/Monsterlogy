using System.Runtime.InteropServices;
using UnityEngine;

namespace Monstrology
{
    public static class WebGLPlatformBridge
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        private static extern int Monstrology_IsMobileUserAgent();

        [DllImport("__Internal")]
        private static extern int Monstrology_RequestFullscreen();

        [DllImport("__Internal")]
        private static extern float Monstrology_GetSafeInsetLeft();

        [DllImport("__Internal")]
        private static extern float Monstrology_GetSafeInsetRight();

        [DllImport("__Internal")]
        private static extern float Monstrology_GetSafeInsetTop();

        [DllImport("__Internal")]
        private static extern float Monstrology_GetSafeInsetBottom();
#endif

        public static bool IsMobileUserAgent()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            try
            {
                return Monstrology_IsMobileUserAgent() == 1;
            }
            catch
            {
                return false;
            }
#else
            return false;
#endif
        }

        public static bool RequestFullscreen()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            try
            {
                return Monstrology_RequestFullscreen() == 1;
            }
            catch
            {
                return false;
            }
#else
            Screen.fullScreen = !Screen.fullScreen;
            return true;
#endif
        }

        public static Rect GetNormalizedSafeArea()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            try
            {
                float left = Mathf.Clamp01(Monstrology_GetSafeInsetLeft());
                float right = Mathf.Clamp01(Monstrology_GetSafeInsetRight());
                float top = Mathf.Clamp01(Monstrology_GetSafeInsetTop());
                float bottom = Mathf.Clamp01(Monstrology_GetSafeInsetBottom());
                return Rect.MinMaxRect(
                    left,
                    bottom,
                    Mathf.Max(left, 1f - right),
                    Mathf.Max(bottom, 1f - top));
            }
            catch
            {
                return new Rect(0f, 0f, 1f, 1f);
            }
#else
            return new Rect(0f, 0f, 1f, 1f);
#endif
        }
    }
}
